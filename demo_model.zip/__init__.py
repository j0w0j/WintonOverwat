"""
Autur: Bart Barnard
Date: 6 april 2026
"""

from .model import DemoClassifier

def model_factory():
    return DemoClassifier()
